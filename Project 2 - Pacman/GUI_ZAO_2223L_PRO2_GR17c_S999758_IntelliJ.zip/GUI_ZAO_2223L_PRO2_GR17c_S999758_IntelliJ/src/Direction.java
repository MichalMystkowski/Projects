public enum Direction {
    up, down, left, right, none
}
