import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Menu extends JFrame {

    public Menu(){
        init();
    }

    public void init(){
        this.setSize(240,320);
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setLayout(null);
        this.setName("Menu");

        Menu menu = this;

        JButton start;

        start = new JButton("Start");
        start.setSize(150,36);
        start.setLocation(getWidth()/2-start.getWidth()/2, 30);
        start.setOpaque(false);
        start.setContentAreaFilled(false);
        start.setBorderPainted(false);
        start.addActionListener(e -> {
            menu.dispose();
            new Thread(() -> new Window()).start();
        });

        add(start);

        JButton highScore;
        highScore = new JButton("High scores");
        highScore.setSize(150,36);
        highScore.setLocation(getWidth()/2-start.getWidth()/2, 110);
        highScore.setOpaque(false);
        highScore.setContentAreaFilled(false);
        highScore.setBorderPainted(false);
        highScore.addActionListener(e -> {
            menu.dispose();
            new Thread(() -> new HighScores(true)).start();
        });

        add(highScore);

        JButton exit;

        exit = new JButton("Exit");
        exit.setSize(150,36);
        exit.setLocation(getWidth()/2-start.getWidth()/2, 190);
        exit.setOpaque(false);
        exit.setContentAreaFilled(false);
        exit.setBorderPainted(false);
        exit.addActionListener(e -> {
            menu.dispose();
        });
        add(exit);

        this.setVisible(true);
    }
}
