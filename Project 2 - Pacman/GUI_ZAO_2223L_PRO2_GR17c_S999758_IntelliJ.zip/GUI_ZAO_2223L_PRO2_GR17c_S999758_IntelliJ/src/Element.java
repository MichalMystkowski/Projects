import java.util.Random;

public class Element extends Grid{

    public Element(Type type, int posX, int posY, Window window) {
        super(type, posX, posY, window);
    }

    @Override
    public void action() {
        if(type == Type.EMPTY && window.countUpgrades() < 3 && new Random().nextInt(20)==5)
        {
            Grid[][] grids = window.getGrids();
            window.remove(grids[posX/20][posY/20]);
            switch (new Random().nextInt(3)) {
                case 0 -> { grids[posX / 20][posY / 20] = new Element(Type.UPGRADE1, posX, posY, window); }
                case 1 -> { grids[posX / 20][posY / 20] = new Element(Type.UPGRADE2, posX, posY, window); }
                case 2 -> { grids[posX / 20][posY / 20] = new Element(Type.UPGRADE3, posX, posY, window); }
            }
        }
    }
}