import javax.swing.*;
import java.util.Random;

public class Enemy extends Grid {

    private Direction direction = Direction.none;
    public boolean moved = false;
    public Enemy(int posX, int posY, Window window) {
        super(Type.GHOST, posX, posY, window);
        changeDirection();
    }

    @Override
    public void action() {
        move();
    }

    public void move() {

        if(moved)
            return;

        moved = true;

        Grid[][] grids = window.getGrids();
        System.out.println("enemy move");
        switch (direction) {
            case up -> {

                if (posY / 20 - 1 < 0) {
                    changeDirection();
                    return;
                }


                if(grids[getIndexX()][getIndexY()-1].type == Type.PACMAN)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }

                if (grids[posX / 20][posY / 20 - 1].type == Type.EMPTY) {
                    window.remove(grids[posX / 20][posY / 20 - 1]);
                    grids[posX / 20][posY / 20 - 1] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posY -= 20;
                    this.setLocation(posX, posY);
                } else if (grids[posX / 20][posY / 20 - 1].type == Type.EMPTY_WITH_SCORE) {
                    window.remove(grids[posX / 20][posY / 20 - 1]);
                    grids[posX / 20][posY / 20 - 1] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY_WITH_SCORE, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posY -= 20;
                    this.setLocation(posX, posY);
                } else {
                    changeDirection();
                }
            }
            case down -> {

                if (getIndexY() + 1 > window.sizeY - 1) {
                    changeDirection();
                    return;
                }

                if(grids[getIndexX()][getIndexY() + 1].type == Type.PACMAN)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }


                if (grids[posX / 20][posY / 20 + 1].type == Type.EMPTY) {
                    window.remove(grids[posX / 20][posY / 20 + 1]);
                    grids[posX / 20][posY / 20 + 1] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posY += 20;
                    this.setLocation(posX, posY);
                } else if (grids[posX / 20][posY / 20 + 1].type == Type.EMPTY_WITH_SCORE) {
                    window.remove(grids[posX / 20][posY / 20 + 1]);
                    grids[posX / 20][posY / 20 + 1] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY_WITH_SCORE, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posY += 20;
                    this.setLocation(posX, posY);
                } else {
                    changeDirection();
                }

            }
            case left -> {

                if(getIndexX()-1 < 0)
                {
                    changeDirection();
                    return;
                }

                if(grids[getIndexX() - 1][getIndexY()].type == Type.PACMAN)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }

                if (grids[posX / 20 - 1][posY / 20].type == Type.EMPTY) {
                    window.remove(grids[posX / 20 - 1][posY / 20]);
                    grids[posX / 20 - 1][posY / 20] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posX -= 20;
                    this.setLocation(posX, posY);
                } else if (grids[posX / 20 - 1][posY / 20].type == Type.EMPTY_WITH_SCORE) {
                    window.remove(grids[posX / 20 - 1][posY / 20]);
                    grids[posX / 20 - 1][posY / 20] = this;
                    grids[posX / 20][posY / 20] = new Element(Type.EMPTY_WITH_SCORE, posX, posY, window);
                    grids[posX / 20][posY / 20].setLocation(posX, posY);

                    posX -= 20;
                    this.setLocation(posX, posY);
                } else {
                    changeDirection();
                }
            }
            case right -> {

                if (getIndexX() + 1 > window.sizeX - 1) {

                    changeDirection();
                    return;

                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.PACMAN)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }


                if (grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY) {
                    window.remove(grids[getIndexX() + 1][getIndexY()]);
                    grids[getIndexX() + 1][getIndexY()] = this;
                    grids[getIndexX()][getIndexY()] = new Element(Type.EMPTY, posX, posY, window);
                    posX += 20;
                    this.setLocation(posX, posY);
                } else if (grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY_WITH_SCORE) {
                    window.remove(grids[getIndexX() + 1][getIndexY()]);
                    grids[getIndexX() + 1][getIndexY()] = this;
                    grids[getIndexX()][getIndexY()] = new Element(Type.EMPTY_WITH_SCORE, posX, posY, window);
                    posX += 20;
                    this.setLocation(posX, posY);
                } else {
                    changeDirection();
                }

            }
        }
    }

    public void changeDirection() {
        direction = Direction.values()[new Random().nextInt(4)];
    }
}
