import javax.swing.*;
import java.awt.*;
import java.net.Proxy;

public class Player extends Grid {

    public Direction direction = Direction.none;
    public boolean moved = false;

    public Player(int posX, int posY, Window window) {
        super(Type.PACMAN, posX, posY, window);
    }

    @Override
    public void action() {
        System.out.print("p ");
        move();
    }

    private void move(){
        if(moved)
            return;

        Grid[][] grids = window.getGrids();

        moved = true;

        switch (direction)
        {
            case up -> {

                if(posY/20-1 < 0)
                    return;

                if(grids[getIndexX()][getIndexY()-1].type == Type.UPGRADE1)
                {
                    window.scorePoints += 50;

                }

                if(grids[getIndexX()][getIndexY() - 1].type == Type.UPGRADE2)
                {
                    window.scorePoints += 100;

                }

                if(grids[getIndexX()][getIndexY() - 1].type == Type.UPGRADE3)
                {
                    window.scorePoints += 250;

                }

                if(grids[getIndexX()][getIndexY() - 1].type == Type.GHOST)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;
                    return;
                }

                if(grids[getIndexX()][getIndexY() - 1].type == Type.EMPTY_WITH_SCORE)
                {
                    window.scorePoints += 10;

                }

                if(grids[posX/20][posY/20-1].type == Type.EMPTY || grids[posX/20][posY/20-1].type == Type.EMPTY_WITH_SCORE || grids[getIndexX()][getIndexY() - 1].type == Type.UPGRADE3 || grids[getIndexX()][getIndexY() - 1].type == Type.UPGRADE2 || grids[getIndexX()][getIndexY() - 1].type == Type.UPGRADE1)
                {
                    window.remove(grids[posX/20][posY/20-1]);
                    grids[posX/20][posY/20-1] = this;
                    grids[posX/20][posY/20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX/20][posY/20].setLocation(posX,posY);

                    posY-=20;
                    this.setLocation(posX, posY);
                }
            }
            case down -> {

                if(getIndexY() + 1 > window.sizeY - 1)
                    return;

                if(grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE1)
                {
                    window.scorePoints += 50;

                }

                if(grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE2)
                {
                    window.scorePoints += 100;

                }

                if(grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE3)
                {
                    window.scorePoints += 250;

                }

                if(grids[getIndexX()][getIndexY() + 1].type == Type.GHOST)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;
                    return;
                }

                if(grids[getIndexX()][getIndexY() + 1].type == Type.EMPTY_WITH_SCORE)
                {
                    window.scorePoints += 10;

                }

                if(grids[posX/20][posY/20+1].type == Type.EMPTY || grids[posX/20][posY/20+1].type == Type.EMPTY_WITH_SCORE || grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE1 || grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE2 || grids[getIndexX()][getIndexY() + 1].type == Type.UPGRADE3)
                {
                    window.remove(grids[posX/20][posY/20+1]);
                    grids[posX/20][posY/20+1] = this;
                    grids[posX/20][posY/20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX/20][posY/20].setLocation(posX,posY);

                    posY+=20;
                    this.setLocation(posX, posY);
                }

            }
            case left -> {

                if(getIndexX()-1 < 0)
                    return;

                if(grids[getIndexX() - 1][getIndexY()].type == Type.GHOST)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }

                if(grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE1)
                {
                    window.scorePoints += 50;

                }

                if(grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE2)
                {
                    window.scorePoints += 100;

                }

                if(grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE3)
                {
                    window.scorePoints += 250;

                }

                if(grids[getIndexX() - 1][getIndexY()].type == Type.EMPTY_WITH_SCORE)
                {
                    window.scorePoints += 10;

                }

                if(grids[posX/20-1][posY/20].type == Type.EMPTY || grids[posX/20-1][posY/20].type == Type.EMPTY_WITH_SCORE || grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE1 || grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE2 || grids[getIndexX() - 1][getIndexY()].type == Type.UPGRADE3)
                {
                    window.remove(grids[posX/20-1][posY/20]);
                    grids[posX/20-1][posY/20] = this;
                    grids[posX/20][posY/20] = new Element(Type.EMPTY, posX, posY, window);
                    grids[posX/20][posY/20].setLocation(posX,posY);

                    posX-=20;
                    this.setLocation(posX, posY);
                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.GHOST)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY_WITH_SCORE)
                {
                    window.scorePoints += 10;

                }
            }
            case right -> {

                if(getIndexX() + 1 > window.sizeX - 1)
                    return;

                if(grids[getIndexX() + 1][getIndexY()].type == Type.GHOST)
                {
                    JOptionPane.showMessageDialog(window, "You lost!");
                    window.end = true;

                    return;
                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE1)
                {
                    window.scorePoints += 50;

                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE2)
                {
                    window.scorePoints += 100;

                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE3)
                {
                    window.scorePoints += 250;

                }

                if(grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY_WITH_SCORE)
                {
                    window.scorePoints += 10;

                }
                if(grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY || grids[getIndexX() + 1][getIndexY()].type == Type.EMPTY_WITH_SCORE || grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE3 || grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE2 || grids[getIndexX() + 1][getIndexY()].type == Type.UPGRADE1)
                {
                    window.remove(grids[getIndexX() + 1][getIndexY()]);
                    grids[getIndexX() + 1][getIndexY()] = this;
                    grids[getIndexX()][getIndexY()] = new Element(Type.EMPTY, posX, posY, window);
                    posX+=20;
                    this.setLocation(posX, posY);
                }
            }
        }
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }
}
