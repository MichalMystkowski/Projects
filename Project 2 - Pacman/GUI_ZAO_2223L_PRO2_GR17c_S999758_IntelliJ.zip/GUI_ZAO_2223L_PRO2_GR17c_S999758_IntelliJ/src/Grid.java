import javax.swing.*;
import java.awt.*;

public abstract class Grid extends JTable {

    protected final int sizeX = 20, sizeY = 20;
    protected int posX, posY;
    protected Type type;
    protected Window window;

    public Grid(Type type, int posX, int posY, Window window) {
        this.setSize(sizeX, sizeY);

        this.setLocation(posX, posY);
        this.window = window;

        this.posX = posX;
        this.posY = posY;

        this.type = type;

        setColor();
        window.add(this);

    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    @Override
    public void paint(Graphics g) {
        Image i = loadImageForType();
        if(i != null) {

            g.drawImage(i, posX,posY, null);
            super.paint(g);

        }
        else {
            super.paint(g);
        }
    }

    public int getIndexX(){return posX/sizeX;}
    public int getIndexY(){return posY/sizeY;}

    public void setType(Type type){
        this.type = type;

        setColor();
    }

    private void setColor(){
        switch (type)
        {
            case EMPTY -> { this.setBackground(Color.LIGHT_GRAY); }
            case PACMAN -> { this.setBackground(Color.YELLOW); }
            case GHOST -> { this.setBackground(Color.BLUE); }
            case WALL -> { this.setBackground(Color.DARK_GRAY); }
            case EMPTY_WITH_SCORE -> { this.setBackground(Color.PINK);}
            case UPGRADE1 -> { this.setBackground(Color.GREEN);}
            case UPGRADE2 -> { this.setBackground(Color.RED);}
            case UPGRADE3 -> { this.setBackground(Color.MAGENTA);}
        }
    }

    private Image loadImageForType(){

        Image ret = null;

        switch (type)
        {
            case PACMAN -> { ret = Toolkit.getDefaultToolkit().createImage("C:\\Users\\kubas\\Desktop\\Pacman\\pacman.png"); }
            case GHOST -> { this.setBackground(Color.BLUE);}
            case WALL -> { this.setBackground(Color.DARK_GRAY);}
            case EMPTY_WITH_SCORE -> { this.setBackground(Color.PINK);}
        }

        return ret;
    }

    public abstract void action();
    public enum Type {
        EMPTY,
        PACMAN,
        GHOST,
        WALL,
        EMPTY_WITH_SCORE,
        UPGRADE1,
        UPGRADE2,
        UPGRADE3
    }

    class TableColour extends javax.swing.table.DefaultTableCellRenderer
    {
        @Override
        public void paint(Graphics g) {
            g.setColor(Color.MAGENTA);
            g.fillRect(posX,posY,20,20);
        }
    }
}
