import java.io.Serializable;
import java.util.Comparator;

public class HighScore implements Serializable, Comparator<HighScore> {
    public String playerName;
    public String score;

    public HighScore(){

    }

    public HighScore(String playerName, String score) {
        this.playerName = playerName;
        this.score = score;
    }

    @Override
    public int compare(HighScore h1, HighScore h2) {
        if(Integer.parseInt(h1.score) < Integer.parseInt(h2.score))
            return 1;
        else if (Integer.parseInt(h1.score) == Integer.parseInt(h2.score))
            return 0;
        else
            return -1;

    }
}
