import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;

public class HighScores extends JFrame {

    private JTextField highScore1;
    private JTextField highScore2;
    private JTextField highScore3;
    private JTextField highScore4;
    private JTextField highScore5;
    private JButton menu;

    HighScoreData highScoreData;

    private boolean showFrame;

    public HighScores(boolean showFrame){
        this.showFrame = showFrame;
        if(showFrame)
            init();
        loadData();
    }

    public void init() {
        this.setSize(300,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBackground(Color.darkGray);
        this.setResizable(false);
        this.setLayout(null);
        this.setLocation(1920/2-getWidth()/2,1080/2-getHeight()/2);
        createComponents();
        this.setVisible(true);
    }

    public void createComponents() {

        highScore1 = new JTextField("");
        highScore1.setSize(200,30);
        highScore1.setLocation(getWidth()/2-highScore1.getWidth()/2, 20);
        highScore1.setEditable(false);
        add(highScore1);

        highScore2 = new JTextField("");
        highScore2.setSize(200,30);
        highScore2.setLocation(getWidth()/2-highScore2.getWidth()/2, 100);
        highScore2.setEditable(false);
        add(highScore2);

        highScore3 = new JTextField("");
        highScore3.setSize(200,30);
        highScore3.setLocation(getWidth()/2-highScore3.getWidth()/2, 180);
        highScore3.setEditable(false);
        add(highScore3);

        highScore4 = new JTextField("");
        highScore4.setSize(200,30);
        highScore4.setLocation(getWidth()/2-highScore4.getWidth()/2, 260);
        highScore4.setEditable(false);
        add(highScore4);

        highScore5 = new JTextField("");
        highScore5.setSize(200,30);
        highScore5.setLocation(getWidth()/2-highScore5.getWidth()/2, 340);
        highScore5.setEditable(false);
        add(highScore5);

        menu = new JButton("Menu");
        menu.setSize(80,30);
        menu.setLocation(200,410);
        menu.addActionListener(e->{
            this.dispose();
            Menu menu = new Menu();
        });
        add(menu);

    }

    public void loadData(){
        highScoreData = HighScoreData.readHighScores();

        if(highScoreData == null)
        {
            saveData();
        }

        if(showFrame) {
            highScore1.setText(highScoreData.highScores.get(0).playerName + ":" + highScoreData.highScores.get(0).score);
            highScore2.setText(highScoreData.highScores.get(1).playerName + ":" + highScoreData.highScores.get(1).score);
            highScore3.setText(highScoreData.highScores.get(2).playerName + ":" + highScoreData.highScores.get(2).score);
            highScore4.setText(highScoreData.highScores.get(3).playerName + ":" + highScoreData.highScores.get(3).score);
            highScore5.setText(highScoreData.highScores.get(4).playerName + ":" + highScoreData.highScores.get(4).score);
        }
    }

    public void saveData(){
        HighScore h1 = new HighScore();
        h1.playerName = "Player1";
        h1.score = "1";

        HighScore h2 = new HighScore();
        h2.playerName = "Player2";
        h2.score = "1";

        HighScore h3 = new HighScore();
        h3.playerName = "Player3";
        h3.score = "1";

        HighScore h4 = new HighScore();
        h4.playerName = "Player4";
        h4.score = "1";

        HighScore h5 = new HighScore();
        h5.playerName = "Player5";
        h5.score = "1";

        if(highScoreData == null) {
            highScoreData = new HighScoreData();
            highScoreData.highScores.add(h1);
            highScoreData.highScores.add(h2);
            highScoreData.highScores.add(h3);
            highScoreData.highScores.add(h4);
            highScoreData.highScores.add(h5);
        }
        HighScoreData.saveHighScores(highScoreData);
    }

    public class HighScoreData implements Serializable {

        public ArrayList<HighScore> highScores = new ArrayList<>();

        public static HighScoreData readHighScores(){

            try {
                FileInputStream fis = new FileInputStream("highscore");
                ObjectInputStream ois = new ObjectInputStream(fis);
                HighScoreData ret = (HighScoreData)ois.readObject();
                ret.highScores.sort((o1, o2) -> {
                    if(Integer.parseInt(o1.score) > Integer.parseInt(o2.score)) return -1;
                    return 1;
                });
                return ret;
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Nie znaleziono pliku z najwyższymi wynikami punktów!");
            }

            return null;
        }

        public static void saveHighScores(HighScoreData highScoreData){
            try{
                FileOutputStream fos = new FileOutputStream("highscore");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(highScoreData);
                oos.close();
                fos.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }

        public static void AddHighScore(String playerName, int score){
            HighScoreData hsd = HighScoreData.readHighScores();
            hsd.highScores.add(new HighScore(playerName, Integer.toString(score)));
            HighScoreData.saveHighScores(hsd);
        }
    }
}